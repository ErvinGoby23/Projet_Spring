package org.efrei.start.dto;

public class CreateActeur {
    private String nom;

    private String filmId;


    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return Prenom;
    }

    public void setPrenom(String prenom) {
        Prenom = prenom;
    }

    private String Prenom;

    public String getFilm_id() {
        return filmId;
    }

    public void setFilm_id(String filmId) {
        this.filmId = filmId;
    }

}
