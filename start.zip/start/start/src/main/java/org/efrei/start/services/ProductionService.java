package org.efrei.start.services;

import org.efrei.start.models.Production;
import org.efrei.start.repositories.ProductionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductionService {

    private final ProductionRepository repository;

    @Autowired
    public ProductionService(ProductionRepository repository) {
        this.repository = repository;
    }

    public List<Production> findAll() {
        return repository.findAll();
    }

    public Production findById(String id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void create(Production production) {
        repository.save(production);
    }

    public void update(String id, Production production) {
        Production existingProduction = findById(id);
        if (existingProduction != null) {
            existingProduction.setNom(production.getNom());
            existingProduction.setAnneeCreation(production.getAnneeCreation());
            repository.save(existingProduction);
        }
    }
}
