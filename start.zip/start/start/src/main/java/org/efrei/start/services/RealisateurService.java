package org.efrei.start.services;

import org.efrei.start.models.Realisateur;
import org.efrei.start.repositories.RealisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RealisateurService {

    private final RealisateurRepository repository;

    @Autowired
    public RealisateurService(RealisateurRepository repository) {
        this.repository = repository;
    }



    public List<Realisateur> findAll() {
        return repository.findAll();
    }

    public void create(Realisateur realisateur) {
        repository.save(realisateur);
    }

    public Realisateur findById(String id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, Realisateur realisateur) {
        Realisateur existingRealisateur = findById(id);
        if (existingRealisateur != null) {
            existingRealisateur.setNom(realisateur.getNom());
            existingRealisateur.setPrenom(realisateur.getPrenom());
            repository.save(existingRealisateur);
        }
    }
}
