package org.efrei.start.controllers;

import org.efrei.start.models.Production;
import org.efrei.start.services.ProductionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productions")
public class ProductionController {

    private final ProductionService service;

    @Autowired
    public ProductionController(ProductionService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Production>> findAll() {
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Production> findById(@PathVariable String id) {
        Production production = service.findById(id);
        if (production == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(production, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable String id) {
        Production production = service.findById(id);
        if (production == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Production production) {
        service.create(production);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable String id, @RequestBody Production production) {
        Production existingProduction = service.findById(id);
        if (existingProduction == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.update(id, production);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
