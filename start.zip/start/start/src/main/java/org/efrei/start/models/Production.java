package org.efrei.start.models;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Production {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    @Column(name = "nom", nullable = false, length = 255)
    private String nom;

    @Column(name = "annee_creation", nullable = false)
    private Integer anneeCreation;

    @ManyToMany(mappedBy = "productions")
    private Set<Realisateur> realisateurs = new HashSet<>();

    // Constructeurs
    public Production(String nom, Integer anneeCreation) {
        this.nom = nom;
        this.anneeCreation = anneeCreation;
    }

    public Production() {}

    // Getters et Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Integer getAnneeCreation() {
        return anneeCreation;
    }

    public void setAnneeCreation(Integer anneeCreation) {
        this.anneeCreation = anneeCreation;
    }

    public Set<Realisateur> getRealisateurs() {
        return realisateurs;
    }

    public void setRealisateurs(Set<Realisateur> realisateurs) {
        this.realisateurs = realisateurs;
    }
}
