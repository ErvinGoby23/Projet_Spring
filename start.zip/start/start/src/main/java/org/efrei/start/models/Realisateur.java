package org.efrei.start.models;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Realisateur {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    @Column(name = "nom", nullable = false, length = 255)
    private String nom;

    @Column(name = "prenom", nullable = false, length = 255)
    private String prenom;

    @ManyToMany
    @JoinTable(
            name = "realisateur_production",
            joinColumns = @JoinColumn(name = "realisateur_id"),
            inverseJoinColumns = @JoinColumn(name = "production_id")
    )
    private Set<Production> productions = new HashSet<>();

    // Constructeurs
    public Realisateur(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    public Realisateur() {}

    // Getters et Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Set<Production> getProductions() {
        return productions.isEmpty() ? null : productions;
    }

    public void setProductions(Set<Production> productions) {
        this.productions = productions;
    }
}
